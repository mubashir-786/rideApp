import { View, Text } from 'react-native'
import React from 'react'

export default function Continue() {
  return (
    <View>
      <Text>continue</Text>
    </View>
  )
}